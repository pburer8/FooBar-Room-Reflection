import java.util.HashMap;
import java.lang.Math;

class Main {
	public static int[][] flipX(int[][] room, int t) {
		//A double-flipped room is the same as the normal room
		if (t % 2 == 0) {
			return room;
		}

		int[][] roomX = new int[room.length][room[0].length];

		for (int i = 0; i<room.length; i++)
			{
				for (int j = 0; j<room[0].length; j++)
					{
						roomX[i][j] = room[room.length-i-1][j];
					}
			}
		return roomX;
	}

	public static int[][] flipY(int[][] room, int t) {
		//A double-flipped room is the same as the normal room
		if (t % 2 == 0) {
			return room;
		}

		int[][] roomY = new int[room.length][room[0].length];

		for (int i = 0; i<room.length; i++)
			{
				for (int j = 0; j<room[0].length; j++)
					{
						roomY[i][j] = room[i][room[0].length-j-1];
					}
			}
		return roomY;
	}

	public static int[][] flipXY(int[][] room, int x, int y) {
		return flipX(flipY(room, y), x);
	}

	public static void main(String[] args) {

		/*
		This problem is "If you are standing in a room with certain dimensions at a certain point, and there is a target standing in the room at another point, how many ways can you fire a laser that can go some distance before disappearing, which also bounces off walls perfectly, such that you hit the target but not yourself"
		*/
		int[] dimensions = { 2, 5 };
		int[] your_position = { 1, 2 };
		int[] trainer_position = { 1, 4 };
		int distance = 11;

		//some constants to use for graphical context
		final int x = 0;
		final int y = 1;

		//how many rooms we have to iterate over
		int xRooms = (int) Math.round((double)distance / dimensions[x]);
		int yRooms = (int) Math.round((double)distance / dimensions[y]);

		//Creating a model of the room where there are walls to avoid (outer ring of 0's)
		//People are represented with a 1, trainers are represented with a -1
		//This solution also allows for objects to be placed inside of the room (that absorb laser)
		int[][] room = new int[dimensions[x]+1][dimensions[y]+1];
		room[your_position[x]][your_position[y]] = 1;
		room[trainer_position[x]][trainer_position[y]] = -1;
		
		//String to record coordinates as x~y, Integer to record type (1/-1)
		HashMap<String, Integer> coordinates = new HashMap<String, Integer>();

		for (int i = -xRooms; i<=xRooms; i++)
			{
				for (int j = -yRooms; j<=yRooms; j++)
					{
						//This represents the bottom left corner of the room's coordinates
						//Used to base everything else off of
						int xCoord = i*dimensions[x];
						int yCoord = j*dimensions[y];

						//Flips the room as many times as we need
						int [][] reflect = flipXY(room, i, j);

						//Find the locations
						for (int k = 0; k<reflect.length; k++)
							{
								for (int l = 0; l<reflect[0].length; l++)
									{
										if (reflect[k][l] != 0)
										{
											//These add the room-perspective position to the mirror-perspective position of the room
											//The room starts at xCoord, yCoord
											//The position of the object in the room is at k,l
											//k+xCoord, l+yCoord represents the total position
											double stringX = k+xCoord;
											double stringY = l+yCoord;

											stringX-=your_position[x];
											stringY-=your_position[y];

											//Personal practice to use the tilde character as a coordinate placeholder
											String stringWhole = ((int) stringX)+"~"+((int) stringY);
							
											coordinates.put(stringWhole, reflect[k][l]);
										}
									}
							}
					}
			}
		
		int c = 0;

		for (HashMap.Entry<String, Integer> entry : coordinates.entrySet()) {
			//Immediately skip if the coordinate does not represent a trainer because we only try to hit trainers
			if (entry.getValue() != -1)
				continue;
			
			String key = entry.getKey();

			//Getting the x and y of the object back
			int xCoord = Integer.valueOf(key.substring(0, key.indexOf("~")));
			int yCoord = Integer.valueOf(key.substring(key.indexOf("~")+1));

			//Distance from 0,0
			double d = Math.sqrt(Math.pow(xCoord, 2)+Math.pow(yCoord,2));

			//Immediately skip if the distance the laser can travel is less than how far away the point is from the origin
			if (d>distance)
				continue;
			
			//Represents the answer to the question "Is there anything in the way of this point from the origin"
			boolean isEmpty = true;

			if (xCoord == 0 && yCoord != 0) //Y-axis
			{
				if (yCoord>0)
				{
					for (int i = yCoord-1; i>0; i--)
						{
							String check = xCoord + "~" + i;

							if (coordinates.containsKey(check))
							{
								isEmpty = false;
							}
						}
				} else
				{
					for (int i = yCoord+1; i<0; i++)
						{
							String check = xCoord + "~" + i;

							if (coordinates.containsKey(check))
							{
								isEmpty = false;
							}
						}
				}
			} else if (yCoord == 0 && xCoord != 0) //X-axis
			{
				if (xCoord>0)
				{
					for (int i = xCoord-1; i>0; i--)
						{
							String check = i + "~" + yCoord;

							if (coordinates.containsKey(check))
							{
								isEmpty = false;
							}
						}
				} else
				{
					for (int i = xCoord+1; i<0; i++)
						{
							String check = i + "~" + yCoord;

							if (coordinates.containsKey(check))
							{
								isEmpty = false;
							}
						}
				}
			} else //All regular cases
			{
				//Represents the greatest common divisor of x and y	
				int factor = 1;

				for (int i = 1; i<=Math.max(Math.abs(xCoord), Math.abs(yCoord)); i++)
					{
						if ((xCoord%i == 0) && (yCoord%i == 0))
						{
							factor = i;
						}
					}

				//The steps that we increase by to check all integer cells
				int xFactorized = xCoord/factor;
				int yFactorized = yCoord/factor;

				for (int i = 1; i<factor; i++)
					{
						String check = i*xFactorized + "~" + i*yFactorized;

						if (coordinates.containsKey(check))
						{
							isEmpty = false;
						}
					}
			}
			if (isEmpty)
			{
				c++;
			}
		}
		System.out.println(c);
	}
}